#!/bin/bash
echo "[JB0TS] Initializing Unified Twin Network..."
echo "[JB0TS] :: Booting J0NB0T..."
python3 engine/boot/j0nb0t_node.py --profile j0nb0t --live &

sleep 1
echo "[JB0TS] :: Booting J$0NB0T..."
python3 engine/boot/j0nb0t_node.py --profile j$0nb0t --live &
